pipeline {
  agent any
  tools {
    maven 'maven'
  }
  stages {
    stage('build Jar') {
      steps {
        script {
          echo "building application...job number:${BUILD_NUMBER}"
          sh 'mvn clean package -Dmaven.test.skip=true'
        }
      }
    }
    stage('build image') {
      steps {
        script {
          echo 'building the image'
          sshagent(['host-podman']) {
               sh "ssh -o StrictHostKeyChecking=no zongli@jenkins.tbb-lab.k8s.tw 'rm -rf /home/zongli/work/test-package-jar-image 2> /dev/null'"
               sh "ssh -o StrictHostKeyChecking=no zongli@jenkins.tbb-lab.k8s.tw 'cd /home/zongli/work  && mkdir test-package-jar-image'"
               sh "scp -r target zongli@jenkins.tbb-lab.k8s.tw:/home/zongli/work/test-package-jar-image"
               sh "scp Dockerfile zongli@jenkins.tbb-lab.k8s.tw:/home/zongli/work/test-package-jar-image"
          }
          def podmanCmdtest = "cd /home/zongli/work/test-package-jar-image && ls"
          sshagent(['host-podman']) {
               sh "ssh -o StrictHostKeyChecking=no zongli@jenkins.tbb-lab.k8s.tw '${podmanCmdtest}'"
          }

          //Define cmd with multiple lines:
          def podmanBuildCmd = "cd /home/zongli/work/test-package-jar-image && podman build -t nexus.tbb-lab.k8s.tw:5000/jenkins-test:1.0 ."

          sshagent(['host-podman']) {
               withCredentials([usernamePassword(credentialsId: 'nexus-push-image', passwordVariable: 'NEXUSPASS' , usernameVariable: 'NEXUSUSER')]){
                   sh "ssh -o StrictHostKeyChecking=no zongli@jenkins.tbb-lab.k8s.tw '${podmanBuildCmd}'"

                   def podmanLogin = "echo $NEXUSPASS | podman login -u $NEXUSUSER nexus.tbb-lab.k8s.tw:5000 --password-stdin "
                   def podmanPush = "podman push nexus.tbb-lab.k8s.tw:5000/jenkins-test:1.0"
                   sh "ssh -o StrictHostKeyChecking=no zongli@jenkins.tbb-lab.k8s.tw '${podmanLogin} && ${podmanPush}'"
               }
          }
        }
      }
    }
    stage('Deploy image') {
      steps {
        script {
          echo 'Deploying application image...'
          sh "cat deployment.yaml"
          sh "kubectl config get-contexts"
          sh "kubectl config set-context --current --namespace=student01-jenkins"
          sh "kubectl get deployment"
          sh "kubectl delete -f deployment.yaml --ignore-not-found=true"
          sh "kubectl apply -f deployment.yaml"
        }
      }
    }
  }
}
